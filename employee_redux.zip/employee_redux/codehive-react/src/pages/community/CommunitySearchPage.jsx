export default function CommunitySearchPage() {
    return (
        <>
            <h1>검색 결과 표시창</h1>
        </>
    )
}