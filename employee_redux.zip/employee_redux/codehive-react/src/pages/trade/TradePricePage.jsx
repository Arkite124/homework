export default function TradePricePage() {
    return (
        <>
            <h1>거래소 시세 페이지</h1>
        </>
    );
}