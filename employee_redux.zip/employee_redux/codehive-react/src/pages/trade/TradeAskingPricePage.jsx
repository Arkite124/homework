export default function TradeAskingPricePage() {
    return (
        <>
            <h1>호가 페이지</h1>
            <p>dddd</p>
        </>
    );
};