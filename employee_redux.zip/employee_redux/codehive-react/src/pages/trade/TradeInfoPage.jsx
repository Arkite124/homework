export default function TradeInfoPage() {
    return (
        <>
            <h1>거래소 정보 페이지</h1>
        </>
    );
}