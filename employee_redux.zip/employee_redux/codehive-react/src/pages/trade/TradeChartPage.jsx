export default function TradeChartPage() {
    return (
        <>
            <h1>거래소 차트 페이지</h1>
        </>
    );
}