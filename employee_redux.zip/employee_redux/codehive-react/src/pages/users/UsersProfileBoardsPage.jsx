export default function UsersProfileBoardsPage() {
    return (
        <>
            <h1>유저프로필게시물페이지</h1>
        </>
    )
}