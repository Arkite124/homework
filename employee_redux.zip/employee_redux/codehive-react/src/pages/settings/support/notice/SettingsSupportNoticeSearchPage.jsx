export default function SettingsSupportNoticeSearchPage() {
    return (
        <>
            <h1>공지사항 검색 결과</h1>
        </>
    );
}