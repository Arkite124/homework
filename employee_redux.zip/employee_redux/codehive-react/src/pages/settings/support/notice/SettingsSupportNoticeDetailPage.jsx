export default function SettingsSupportNoticeDetailPage() {
    return (
        <>
            <h1>공지사항 디테일</h1>
        </>
    );
}