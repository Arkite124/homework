export default function SettingsSupportFaqDetailPage() {
    return (
        <>
            <h1>자주묻는 질문 디테일</h1>
        </>
    );
}