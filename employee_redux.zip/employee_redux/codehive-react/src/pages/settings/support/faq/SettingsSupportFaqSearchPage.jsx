export default function SettingsSupportFaqSearchPage() {
    return (
        <>
            <h1>자주묻는질문 검색결과</h1>
        </>
    );
}