export default function SettingsSupportQnaQuestionDetailPage() {
    return (
        <>
            <h1>문의 내역 디테일</h1>
        </>
    );
}