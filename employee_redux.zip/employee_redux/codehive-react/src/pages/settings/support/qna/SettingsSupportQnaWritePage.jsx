export default function SettingsSupportQnaWritePage() {
    return (
        <>
            <h1>1:1 문의하기 작성페이지</h1>
        </>
    );
}