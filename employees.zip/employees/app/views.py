from rest_framework import status
from rest_framework.decorators import api_view, permission_classes
from rest_framework.generics import get_object_or_404
from rest_framework.permissions import AllowAny
from rest_framework.response import Response

from .models import Employee
from .serializers import EmployeeSerializer


# Create your views here.
@api_view(['GET', 'POST'])
@permission_classes([AllowAny])
def employees(request):
    if request.method == 'GET':
        infos = Employee.objects.all()
        return Response(EmployeeSerializer(infos, many=True).data)
    response = request.data
    print(response)
    serializer = EmployeeSerializer(data=response)
    if serializer.is_valid():
        serializer.save()
        return Response(serializer.data, status=status.HTTP_201_CREATED)
    return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

@api_view(['DELETE','PUT','PATCH'])
@permission_classes([AllowAny])
def employee_detail(request,name):
    if request.method == 'DELETE':
        emp = get_object_or_404(Employee, name=name)
        print(emp)
        emp.delete()
        return Response(status=status.HTTP_204_NO_CONTENT)
    if request.method in ['PUT','PATCH']:
        emp = get_object_or_404(Employee, name=name)
        print(emp)
        if request.method in ['PUT', 'PATCH']:
            serializer = EmployeeSerializer(emp,data=request.data)
            if serializer.is_valid():
                serializer.update(emp,serializer.validated_data)
                return Response(serializer.data)
            return Response("내용이 잘못되었습니다.", status=status.HTTP_400_BAD_REQUEST)
    return Response("잘못된 전송 형식입니다.",status=status.HTTP_500_INTERNAL_SERVER_ERROR)
